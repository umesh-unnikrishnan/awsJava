import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class TestMain {

	 public static int countRows=0;
	public static void main(String[] args) {
		
		 SimpleDateFormat sdfIn = new SimpleDateFormat("ssssss");
		    SimpleDateFormat sdfOut = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		    String input ="489726562";
		    Date date;
			try {
				date = sdfIn.parse(input);
				 System.out.println("sdfOut.format(date)="+sdfOut.format(date));	
				 String test=sdfOut.format(date).toString();
				System.out.println(test);
				 
			} catch (java.text.ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		/*String test="123fgdgdf4567";
		
			
		if(!test.matches("[0-9]+"))
		{
			System.out.println("***");
		}
		else
		{
			System.out.println("piya");
		}
		/*
		LineNumberReader reader;
		File file = new File("C:\\Users\\1221560\\Documents\\JavaWorkspace\\dataBlockChain.csv");
		FileInputStream fis;
		String line;
		try {
			testfunction(file);
			fis = new FileInputStream(file);
			reader = new LineNumberReader(new InputStreamReader(fis));
			System.out.println("countRows ="+countRows);
			while ((line = reader.readLine()) !=null){
				System.out.println("reader.getLineNumber() ="+reader.getLineNumber());
			}		
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		// TODO Auto-generated method stub
	/*	String string=" CoEBCAESQhJAZWNjNGNkOTVhMmMwYWNkZDA3Y2MyNGYzNDFjNzk5YmNmNzE4OTA0ZjNiMWY0YzMzMTBmYzk4NzM0ZDcyOWIyNxo5Cgt1cGRhdGVBc3NldAoFMTIzNDUKBXAxMjM0CgIxMAoEdGVzdAoCMjAKAzFBTQoFRmVkRXgKAi0y   txid ";
		System.out.println("string:"+string);
		
		System.out.println("*** string.replaceAll(string, txtid)="+string.substring(1, string.length()-8));
		if (string.contains("[a-zA-Z]+") == false || string.contains("[0-9]+") == false) {
		   System.out.println("111/string="+string); 
		}
		else
		{
			
		}	
		
		   System.out.println("///string="+string.contains("[a-zA-Z]+")); 
		   System.out.println("///string="+string.contains("[0-9]+")); 
		   
		 
		   SimpleDateFormat sdfIn = new SimpleDateFormat("ssssss");
		    SimpleDateFormat sdfOut = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		    String input ="1489518798";
		    Date date;
			try {
				date = sdfIn.parse(input);
				 System.out.println("sdfOut.format(date)="+sdfOut.format(date));	
				 String test=sdfOut.format(date).toString();
				System.out.println(test);
				 
			} catch (java.text.ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	*/}

	private static int testfunction(File file) {
		// TODO Auto-generated method stub
		FileInputStream fis;
		try {
			fis = new FileInputStream(file);
			LineNumberReader reader = new LineNumberReader(new InputStreamReader(fis));
			String line;
			while ((line = reader.readLine()) !=null){
				System.out.println("***="+reader.getLineNumber());
				countRows=reader.getLineNumber();
			}	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return countRows;
		
	}

	

		
}
